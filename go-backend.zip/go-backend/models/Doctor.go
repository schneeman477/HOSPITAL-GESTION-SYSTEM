package models

import "gorm.io/gorm"

type Doctor struct {
	gorm.Model
	Name        string `json:"name"`
	Specialty   string `json:"specialty"`
	PhoneNumber uint   `json:"phone_number"`
	Email       string `json:"email"`
}
