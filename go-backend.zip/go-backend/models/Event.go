// models/appointment.go
package models

import (
	"time"

	"gorm.io/gorm"
)

type Appointment struct {
	gorm.Model
	Title       string    `json:"title"`
	Description string    `json:"description"`
	Date        time.Time `json:"date"`       // Fecha y hora de la cita
	Duration    int       `json:"duration"`   // Duración en minutos
	DoctorID    uint      `json:"doctor_id"`  // ID del doctor asignado
	PatientID   uint      `json:"patient_id"` // Opcional: ID de paciente si se integra
}
