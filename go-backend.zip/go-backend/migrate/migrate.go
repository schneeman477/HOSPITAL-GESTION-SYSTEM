// migrate/migrate.go
package main

import (
	"fmt"

	"agendamiento.com/go-backend/configs"
	"agendamiento.com/go-backend/models"
)

func main() {
	// Conexión a la base de datos
	configs.ConnectToDB()

	// Ejecutar las migraciones
	err := configs.DB.AutoMigrate(&models.Doctor{}, &models.Appointment{}, &models.Person{})
	if err != nil {
		fmt.Println("Error en la migración:", err)
		return
	}

	fmt.Println("Migración completada exitosamente.")
}
