package controllers

import (
	"net/http"

	"agendamiento.com/go-backend/configs"
	"agendamiento.com/go-backend/models"
	"github.com/gin-gonic/gin"
)

type DoctorRequestBody struct {
	Name        string `json:"name"`
	Specialty   string `json:"specialty"`
	PhoneNumber string `json:"phone_number"`
	Email       string `json:"email"`
}

// Obtener todos los doctores
func DoctorGet(c *gin.Context) {
	var doctors []models.Doctor
	configs.DB.Find(&doctors)
	c.JSON(http.StatusOK, &doctors)
}

// Obtener un doctor por ID
func DoctorGetById(c *gin.Context) {
	id := c.Param("id")
	var doctor models.Doctor
	result := configs.DB.First(&doctor, id)
	if result.Error != nil {
		c.JSON(http.StatusNotFound, gin.H{"error": "Doctor not found"})
		return
	}
	c.JSON(http.StatusOK, &doctor)
}

func DoctorUpdate(c *gin.Context) {
	id := c.Param("id")
	var doctor models.Doctor
	if err := configs.DB.First(&doctor, id).Error; err != nil {
		c.JSON(http.StatusNotFound, gin.H{"error": "Doctor not found"})
		return
	}

	var body struct {
		Name        string `json:"name"`
		Specialty   string `json:"specialty"`
		PhoneNumber uint   `json:"phone_number"`
		Email       string `json:"email"`
	}
	c.BindJSON(&body)

	updates := models.Doctor{
		Name:        body.Name,
		Specialty:   body.Specialty,
		PhoneNumber: body.PhoneNumber,
		Email:       body.Email,
	}

	configs.DB.Model(&doctor).Updates(updates)
	c.JSON(http.StatusOK, &doctor)
}

// Eliminar un doctor
func DoctorDelete(c *gin.Context) {
	id := c.Param("id")
	result := configs.DB.Delete(&models.Doctor{}, id)
	if result.RowsAffected == 0 {
		c.JSON(http.StatusNotFound, gin.H{"error": "Doctor not found"})
		return
	}
	c.JSON(http.StatusOK, gin.H{"deleted": true})
}

func CreateDoctor(c *gin.Context) {
	var doctor models.Doctor
	if err := c.ShouldBindJSON(&doctor); err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": err.Error()})
		return
	}
	if result := configs.DB.Create(&doctor); result.Error != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": "Failed to create doctor"})
		return
	}
	c.JSON(http.StatusCreated, &doctor)
}
