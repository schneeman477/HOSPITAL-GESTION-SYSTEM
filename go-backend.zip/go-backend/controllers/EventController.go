// controllers/appointmentController.go
package controllers

import (
	"net/http"
	"time"

	"agendamiento.com/go-backend/configs"
	"agendamiento.com/go-backend/models"
	"github.com/gin-gonic/gin"
)

type AppointmentRequestBody struct {
	Title       string `json:"title"`
	Description string `json:"description"`
	Date        string `json:"date"`       // Fecha y hora en formato RFC3339, e.g., "2024-11-05T15:00:00Z"
	Duration    int    `json:"duration"`   // Duración en minutos
	DoctorID    uint   `json:"doctor_id"`  // ID del doctor asignado a la cita
	PatientID   uint   `json:"patient_id"` // Opcional: ID del paciente, si se está utilizando
}

// Obtener todas las citas
func AppointmentGet(c *gin.Context) {
	var appointments []models.Appointment
	configs.DB.Find(&appointments)
	c.JSON(http.StatusOK, &appointments)
}

// Obtener una cita por ID
func AppointmentGetById(c *gin.Context) {
	id := c.Param("id")
	var appointment models.Appointment
	result := configs.DB.First(&appointment, id)
	if result.Error != nil {
		c.JSON(http.StatusNotFound, gin.H{"error": "Appointment not found"})
		return
	}
	c.JSON(http.StatusOK, &appointment)
}

// Actualizar una cita
func AppointmentUpdate(c *gin.Context) {
	id := c.Param("id")
	var appointment models.Appointment
	if err := configs.DB.First(&appointment, id).Error; err != nil {
		c.JSON(http.StatusNotFound, gin.H{"error": "Appointment not found"})
		return
	}

	var body struct {
		Title       string `json:"title"`
		Description string `json:"description"`
		Date        string `json:"date"` // Formato: "2024-11-05T15:00:00Z"
		Duration    int    `json:"duration"`
		DoctorID    uint   `json:"doctor_id"`
		PatientID   uint   `json:"patient_id"`
	}
	c.BindJSON(&body)

	// Parsear la fecha
	date, err := time.Parse(time.RFC3339, body.Date)
	if err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": "Invalid date format"})
		return
	}

	updates := models.Appointment{
		Title:       body.Title,
		Description: body.Description,
		Date:        date,
		Duration:    body.Duration,
		DoctorID:    body.DoctorID,
		PatientID:   body.PatientID,
	}

	configs.DB.Model(&appointment).Updates(updates)
	c.JSON(http.StatusOK, &appointment)
}

// Eliminar una cita
func AppointmentDelete(c *gin.Context) {
	id := c.Param("id")
	result := configs.DB.Delete(&models.Appointment{}, id)
	if result.RowsAffected == 0 {
		c.JSON(http.StatusNotFound, gin.H{"error": "Appointment not found"})
		return
	}
	c.JSON(http.StatusOK, gin.H{"deleted": true})
}

func CreateAppointment(c *gin.Context) {
	var body struct {
		Title       string `json:"title"`
		Description string `json:"description"`
		Date        string `json:"date"`
		Duration    int    `json:"duration"`
		DoctorID    uint   `json:"doctor_id"`
		PatientID   uint   `json:"patient_id"`
	}
	if err := c.ShouldBindJSON(&body); err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": err.Error()})
		return
	}

	date, err := time.Parse(time.RFC3339, body.Date)
	if err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": "Invalid date format"})
		return
	}

	appointment := models.Appointment{
		Title:       body.Title,
		Description: body.Description,
		Date:        date,
		Duration:    body.Duration,
		DoctorID:    body.DoctorID,
		PatientID:   body.PatientID,
	}

	if result := configs.DB.Create(&appointment); result.Error != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": "Failed to create appointment"})
		return
	}
	c.JSON(http.StatusCreated, &appointment)
}
