package routes

import (
	"agendamiento.com/go-backend/controllers"
	"github.com/gin-gonic/gin"
)

func AppointmentRouter(router *gin.Engine) {
	routes := router.Group("/api/v1/appointments")
	routes.POST("", controllers.CreateAppointment)

	routes.GET("", controllers.AppointmentGet)
	routes.GET("/:id", controllers.AppointmentGetById)
	routes.PUT("/:id", controllers.AppointmentUpdate)
	routes.DELETE("/:id", controllers.AppointmentDelete)

}
