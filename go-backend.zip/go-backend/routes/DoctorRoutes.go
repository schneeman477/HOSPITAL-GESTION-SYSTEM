package routes

import (
	"agendamiento.com/go-backend/controllers"
	"github.com/gin-gonic/gin"
)

func DoctorRouter(router *gin.Engine) {
	routes := router.Group("/api/v1/doctors")
	routes.POST("", controllers.CreateDoctor)
	routes.GET("", controllers.DoctorGet)
	routes.GET("/:id", controllers.DoctorGetById)
	routes.PUT("/:id", controllers.DoctorUpdate)
	routes.DELETE("/:id", controllers.DoctorDelete)

}
