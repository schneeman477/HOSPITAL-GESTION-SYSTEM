package main

import (
	"agendamiento.com/go-backend/configs"
	"agendamiento.com/go-backend/models"
	"agendamiento.com/go-backend/routes"
	"github.com/gin-gonic/gin"
)

func main() {
	configs.ConnectToDB()
	configs.DB.AutoMigrate(&models.Doctor{}, &models.Appointment{}, &models.Person{})

	r := gin.Default()
	routes.PersonRouter(r)
	routes.DoctorRouter(r)
	routes.AppointmentRouter(r)
	r.Run()
}
