package main

import (
	"fmt"
	"log"

	"agendamiento.com/go-backend/configs"
	"agendamiento.com/go-backend/models"
)

func main() {
	// Conexión a la base de datos
	configs.ConnectToDB()

	// Ejecutar las migraciones
	err := configs.DB.AutoMigrate(
		&models.Doctor{},      // Migrar la tabla de doctores
		&models.TimeSlot{},    // Migrar la tabla de tiempos disponibles
		&models.Appointment{}, // Migrar la tabla de citas médicas
	)
	if err != nil {
		fmt.Println("Error en la migración:", err)
		return
	}
	fmt.Println("Migración completada exitosamente.")

	// Poblar los catálogos iniciales
	seedData()
}

// seedData poblará los datos iniciales de la base de datos
func seedData() {
	var count int64

	// Poblar doctores
	configs.DB.Model(&models.Doctor{}).Count(&count)
	if count == 0 {
		// Crear doctores con especialidades como strings
		doctors := []models.Doctor{
			{Name: "Dr. Juan Pérez", Specialty: "Cardiología"},
			{Name: "Dra. Ana García", Specialty: "Dermatología"},
			{Name: "Dr. Carlos Martínez", Specialty: "Neurología"},
			{Name: "Dra. María López", Specialty: "Odontología"},
			{Name: "Dr. Jorge Salazar", Specialty: "Pediatría"},
			{Name: "Dra. Laura Rodríguez", Specialty: "Psiquiatría"},
			{Name: "Dr. Pedro González", Specialty: "Urología"},
			{Name: "Dra. Sofía Fernández", Specialty: "Oncología"},
			{Name: "Dr. Andrés Moreno", Specialty: "Ginecología"},
			{Name: "Dra. Julia Rivera", Specialty: "Anestesiología"},
			{Name: "Dr. Martín Torres", Specialty: "Otorrinolaringología"},
			{Name: "Dra. Daniela Vega", Specialty: "Urgencias"},
		}

		// Insertar los doctores
		if err := configs.DB.Create(&doctors).Error; err != nil {
			log.Fatalf("Error al poblar doctores: %v", err)
		}
		log.Println("Doctores poblados correctamente.")
	}

	// Poblar duraciones
	configs.DB.Model(&models.TimeSlot{}).Count(&count)
	if count == 0 {
		timeSlots := []models.TimeSlot{
			{Start: "08:00", End: "08:30"},
			{Start: "08:30", End: "09:00"},
			{Start: "09:00", End: "09:30"},
			{Start: "09:30", End: "10:00"},
			{Start: "10:00", End: "10:30"},
			{Start: "10:30", End: "11:00"},
			{Start: "11:00", End: "11:30"},
			{Start: "11:30", End: "12:00"},
			{Start: "12:00", End: "12:30"},
			{Start: "12:30", End: "13:00"},
			{Start: "13:00", End: "13:30"},
			{Start: "13:30", End: "14:00"},
			{Start: "14:00", End: "14:30"},
			{Start: "14:30", End: "15:00"},
			{Start: "15:00", End: "15:30"},
		}
		if err := configs.DB.Create(&timeSlots).Error; err != nil {
			log.Fatalf("Error al poblar duraciones: %v", err)
		}
		log.Println("Duraciones pobladas correctamente.")
	}
}
