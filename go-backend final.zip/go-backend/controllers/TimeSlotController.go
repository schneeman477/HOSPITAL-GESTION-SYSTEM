package controllers

import (
	"net/http"

	"agendamiento.com/go-backend/configs"
	"agendamiento.com/go-backend/models"
	"github.com/gin-gonic/gin"
)

// Obtener lista de TimeSlots (duraciones)
func GetTimeSlots(c *gin.Context) {
	var timeSlots []models.TimeSlot
	result := configs.DB.Find(&timeSlots)
	if result.Error != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": result.Error.Error()})
		return
	}

	// Formatear la respuesta
	var slots []map[string]interface{}
	for _, slot := range timeSlots {
		slots = append(slots, map[string]interface{}{
			"id":    slot.ID,
			"start": slot.Start,
			"end":   slot.End,
		})
	}

	c.JSON(http.StatusOK, slots)
}
