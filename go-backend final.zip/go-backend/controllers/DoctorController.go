package controllers

import (
	"net/http"

	"agendamiento.com/go-backend/configs"
	"agendamiento.com/go-backend/models"
	"github.com/gin-gonic/gin"
)

// Obtener lista de doctores con sus especialidades
func GetDoctors(c *gin.Context) {
	var doctors []models.Doctor
	result := configs.DB.Find(&doctors) // Ya no necesitas Preload
	if result.Error != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": result.Error.Error()})
		return
	}

	// Formatear la respuesta (opcional, pero recomendado)
	var doctorList []map[string]interface{}
	for _, doc := range doctors {
		doctorList = append(doctorList, map[string]interface{}{
			"id":        doc.ID,
			"name":      doc.Name,
			"specialty": doc.Specialty, // Accede directamente al campo Specialty
		})
	}

	c.JSON(http.StatusOK, doctorList)
}
