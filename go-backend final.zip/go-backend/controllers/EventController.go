package controllers

import (
	"fmt"
	"net/http"
	"time"

	"agendamiento.com/go-backend/configs"
	"agendamiento.com/go-backend/models"
	"github.com/gin-gonic/gin"
)

// Obtener todas las citas
func GetAppointments(c *gin.Context) {
	var appointments []models.Appointment
	result := configs.DB.Preload("Doctor").Preload("TimeSlot").Find(&appointments)
	if result.Error != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": result.Error.Error()})
		return
	}

	// Construir una respuesta más detallada
	var response []gin.H
	for _, appointment := range appointments {
		response = append(response, gin.H{
			"id":        appointment.ID,
			"date":      appointment.Date.Format("2006-01-02"),
			"title":     appointment.Title,
			"doctor":    appointment.Doctor.Name,
			"specialty": appointment.Doctor.Specialty,
			"time_slot": fmt.Sprintf("%s - %s", appointment.TimeSlot.Start, appointment.TimeSlot.End),
		})
	}

	c.JSON(http.StatusOK, response)
}

// Crear una nueva cita
func CreateAppointment(c *gin.Context) {
	var body struct {
		Title    string `json:"title"`
		Date     string `json:"date"`
		Duration string `json:"duration"`
		DoctorID uint   `json:"doctor_id"`
	}

	if err := c.ShouldBindJSON(&body); err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": "Invalid input format", "details": err.Error()})
		return
	}

	date, err := time.Parse("2006-01-02", body.Date)
	if err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": "Invalid date format. Use 'YYYY-MM-DD'"})
		return
	}

	var doctor models.Doctor
	if err := configs.DB.First(&doctor, body.DoctorID).Error; err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": "Doctor not found with the provided ID"})
		return
	}

	var timeSlot models.TimeSlot
	if err := configs.DB.Where("CONCAT(start, '-', end) = ?", body.Duration).First(&timeSlot).Error; err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": "Invalid duration. Time slot not found"})
		return
	}

	appointment := models.Appointment{
		Title:      body.Title,
		Date:       date,
		TimeSlotID: timeSlot.ID,
		DoctorID:   body.DoctorID,
	}

	if result := configs.DB.Create(&appointment); result.Error != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": "Failed to create the appointment", "details": result.Error.Error()})
		return
	}

	c.JSON(http.StatusCreated, gin.H{
		"message":     "Appointment created successfully",
		"appointment": appointment,
	})
}

// Actualizar una cita existente
func UpdateAppointment(c *gin.Context) {
	id := c.Param("id")
	var appointment models.Appointment

	if err := configs.DB.First(&appointment, id).Error; err != nil {
		c.JSON(http.StatusNotFound, gin.H{"error": "Appointment not found"})
		return
	}

	var body struct {
		Title    string `json:"title"` // Added Title field
		Date     string `json:"date"`
		Duration string `json:"duration"`
		DoctorID uint   `json:"doctor_id"`
	}
	if err := c.ShouldBindJSON(&body); err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": err.Error()})
		return
	}

	date, err := time.Parse("2006-01-02", body.Date)
	if err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": "Invalid date format"})
		return
	}

	var doctor models.Doctor
	if err := configs.DB.First(&doctor, body.DoctorID).Error; err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": "Invalid doctor ID"})
		return
	}

	var timeSlot models.TimeSlot
	if err := configs.DB.Where("CONCAT(start, '-', end) = ?", body.Duration).First(&timeSlot).Error; err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": "Invalid duration"})
		return
	}

	// Update all fields including Title
	appointment.Title = body.Title
	appointment.Date = date
	appointment.TimeSlotID = timeSlot.ID
	appointment.DoctorID = body.DoctorID

	if result := configs.DB.Save(&appointment); result.Error != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": result.Error.Error()})
		return
	}

	c.JSON(http.StatusOK, gin.H{"message": "Appointment updated successfully", "appointment": appointment})
}

// Eliminar una cita existente
func DeleteAppointment(c *gin.Context) {
	id := c.Param("id")
	var appointment models.Appointment

	if err := configs.DB.First(&appointment, id).Error; err != nil {
		c.JSON(http.StatusNotFound, gin.H{"error": "Appointment not found"})
		return
	}

	configs.DB.Delete(&appointment)
	c.JSON(http.StatusOK, gin.H{"message": "Appointment deleted successfully"})
}

// Obtener una cita por ID
func GetAppointmentByID(c *gin.Context) {
	id := c.Param("id")
	var appointment models.Appointment

	if err := configs.DB.Preload("Doctor").Preload("TimeSlot").First(&appointment, id).Error; err != nil {
		c.JSON(http.StatusNotFound, gin.H{"error": "Appointment not found"})
		return
	}

	response := gin.H{
		"id":        appointment.ID,
		"title":     appointment.Title,
		"date":      appointment.Date.Format("2006-01-02"),
		"doctor_id": appointment.DoctorID,
		"time_slot": fmt.Sprintf("%s-%s", appointment.TimeSlot.Start, appointment.TimeSlot.End),
	}

	c.JSON(http.StatusOK, response)
}
