package main

import (
	"agendamiento.com/go-backend/configs"
	"agendamiento.com/go-backend/routes"
	"github.com/gin-gonic/gin"
)

func main() {
	// Inicializar configuración de la base de datos
	configs.ConnectToDB()

	// Crear una nueva instancia de Gin
	router := gin.Default()

	// Servir archivos estáticos para el frontend
	router.Static("/public", "./public")

	// Ruta principal para cargar la portada
	router.GET("/", func(c *gin.Context) {
		c.File("./public/index.html")
	})

	// Ruta para el perfil de Paciente
	router.GET("/paciente", func(c *gin.Context) {
		c.File("./public/paciente.html")
	})

	// Ruta para el perfil de Administrador
	router.GET("/admin", func(c *gin.Context) {
		c.File("./public/admin.html")
	})

	// Configurar todas las rutas de la API
	routes.ConfigureRoutes(router) // Llamamos a la función que configura las rutas

	// Iniciar el servidor en el puerto 8081
	router.Run(":8081")
}
