package models

import (
	"fmt"
	"time"
)

// Modelo de Doctor
type Doctor struct {
	ID        uint   `gorm:"primaryKey" json:"id"` // ID único
	Name      string `gorm:"not null" json:"name"` // Nombre del doctor
	Specialty string `gorm:"not null" json:"name"` // Especialidad asociada
}

// Modelo de Catálogo de Duraciones
type TimeSlot struct {
	ID    uint   `gorm:"primaryKey"` // ID único
	Start string `json:"start"`      // Hora de inicio
	End   string `json:"end"`        // Hora de fin
}

// DurationString devuelve un string con el rango de tiempo (ejemplo: "10:00 AM - 11:00 AM")
func (ts TimeSlot) DurationString() string {
	return fmt.Sprintf("%s - %s", ts.Start, ts.End)
}

// Modelo de la tabla de citas médicas (appointments)
type Appointment struct {
	ID         uint      `gorm:"primaryKey" json:"id"`
	Date       time.Time `gorm:"not null" json:"date"`         // Fecha de la cita
	Title      string    `gorm:"not null" json:"title"`        // Título de la cita
	TimeSlotID uint      `gorm:"not null" json:"time_slot_id"` // Relación con el TimeSlot
	DoctorID   uint      `gorm:"not null" json:"doctor_id"`    // Relación con el Doctor
	TimeSlot   TimeSlot  `gorm:"foreignKey:TimeSlotID;constraint:OnDelete:CASCADE,OnUpdate:CASCADE" json:"time_slot"`
	Doctor     Doctor    `gorm:"foreignKey:DoctorID;constraint:OnDelete:CASCADE,OnUpdate:CASCADE" json:"doctor"`
}
