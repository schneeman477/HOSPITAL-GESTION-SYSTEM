package configs

import (
	"fmt"
	"log"

	"gorm.io/driver/mysql"
	"gorm.io/gorm"
)

var DB *gorm.DB

// ConnectToDB realiza la conexión a la base de datos MySQL
func ConnectToDB() {
	// Se declara una variable de error
	var err error

	// Configuración de la conexión a la base de datos
	dsn := "root:Gualpapa2006#@tcp(127.0.0.1:3306)/agendamiento_go?charset=utf8mb4&parseTime=True&loc=Local"
	DB, err = gorm.Open(mysql.Open(dsn), &gorm.Config{})

	// Verificación de la conexión a la base de datos
	if err != nil {
		log.Fatal("Error al conectar con la base de datos:", err)
	}

	// Confirmación de conexión exitosa
	fmt.Println("Conexión exitosa a la base de datos")
}
