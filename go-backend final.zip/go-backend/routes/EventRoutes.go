package routes

import (
	"agendamiento.com/go-backend/controllers"
	"github.com/gin-gonic/gin"
)

// ConfigureRoutes configura todas las rutas de la API.
func ConfigureRoutes(router *gin.Engine) {
	// Grupo de rutas para la API versión 1
	api := router.Group("/api/v1")
	{
		// Rutas relacionadas con citas médicas
		api.POST("/appointments", controllers.CreateAppointment)       // Crear cita
		api.GET("/appointments", controllers.GetAppointments)          // Obtener todas las citas
		api.GET("/appointments/:id", controllers.GetAppointmentByID)   // Obtener una cita por ID
		api.PUT("/appointments/:id", controllers.UpdateAppointment)    // Actualizar una cita
		api.DELETE("/appointments/:id", controllers.DeleteAppointment) // Eliminar una cita

		// Rutas relacionadas con doctores
		api.GET("/doctors", controllers.GetDoctors) // Obtener lista de doctores

		// Rutas relacionadas con horarios
		api.GET("/time-slots", controllers.GetTimeSlots) // Obtener lista de horarios
	}
}
